# Capstone Part 2 Traffic Analytics Pipeline

Extract the ZIP and open a terminal in capstone_part2 (the folder containing this README).
Install dependencies: python -m pip install -r part2_python/requirements.txt
Verified environment: Python 3.11.17, NumPy 2.4.6, pandas 3.1.1, Matplotlib 3.11.2.

Run the complete pipeline: python pipeline.py --all
Run time features only: python feature_engineering.py
Run scaled and quartile features: python feature_engineering.py --quartiles
Run figures: python visualizations.py

Three analytics commands:
python traffic_app.py at --time "2017-01-01 00:00:00"
python traffic_app.py summary --start 2017-01-01 --end 2017-01-31
python traffic_app.py compare --start 2017-01-01 --end 2017-01-31

Run checks: python -m unittest discover -s part2_python/tests -v
The root scripts are entry-point aliases for the implementation modules. Keep the
whole folder structure: modules locate raw data and outputs relative to this root.
The full pipeline rewrites generated tables/figures and part2_python/pipeline.log;
it does not modify the raw input. CLI logs are separate and overwritten each run.

Report: part2_traffic_pipeline_report.pdf (two pages).
Figures: part2_python/figures (three PNGs with supporting data).
Sample complete log: part2_python/pipeline.log.
Detailed methods, logging and command semantics: part2_python/README.md.
MANIFEST.json lists SHA-256 values for every other packaged file.

Source repository: https://github.com/FSLiao375426/smart-city-traffic-capstone-003
The repository preserves incremental Git history; the ZIP is a portable snapshot.
Data: Hogue (2019), Metro Interstate Traffic Volume, UCI Machine Learning Repository,
https://doi.org/10.24432/C5X60B (CC BY 4.0).
The labels are traffic-volume proxies, not observed accident risk. Full-period plots
are descriptive; the final modelling split and forecast-time inputs remain undecided.
