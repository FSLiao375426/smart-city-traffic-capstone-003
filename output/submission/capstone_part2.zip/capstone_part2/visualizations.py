"""Course-named entry point for part2_python.visualize."""
import logging
from part2_python.visualize import main
logger = logging.getLogger(__name__)

if __name__ == "__main__":
    raise SystemExit(main())
